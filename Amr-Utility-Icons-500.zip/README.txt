AMR Utility - 500 Icon Pack

Contains 500 PNG fallback icons named exactly as each application Id, plus manifest.json.
IMPORTANT: These are generated initials-based fallback icons, NOT official application logos and NOT images downloaded from the Internet.
Copy the contents of the Icons folder into %ProgramData%\AMR-Utility\Icons to use them with the current local-icon lookup.
To replace an icon with an official/approved logo, keep the exact filename (for example Google.Chrome.png).
